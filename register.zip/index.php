<?php
define('APP_DEBUG', true);//线下调试模式
define('CSS','/register/Public/Home/css');
define('JS','/register/Public/Home/js');
define('IMG','/register/Public/Home/img');



define('UED','/register/Public/Ueditor/full');

include './ThinkPHP/ThinkPHP.php';

?>